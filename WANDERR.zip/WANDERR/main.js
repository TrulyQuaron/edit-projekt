let cart =
    JSON.parse(
        localStorage.getItem("cart" + localStorage.getItem("currentUserIndex"))
    ) || [];
const gradovi = [
    { 'id': 'Bangkok', 'kontinent': 'Azija', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 883 }, { 'id': 'VL', 'n': 752 }, { 'id': 'BUS', 'n': 557 }] },
    { 'id': 'Beograd', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 119 }, { 'id': 'VL', 'n': 153 }, { 'id': 'BUS', 'n': 285 }] },
    { 'id': 'Berlin', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 236 }, { 'id': 'VL', 'n': 293 }, { 'id': 'BUS', 'n': 203 }] },
    { 'id': 'Brasília', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 763 }, { 'id': 'BUS', 'n': 746 }] },
    { 'id': 'Buenos Aires', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 730 }, { 'id': 'BUS', 'n': 654 }] },
    { 'id': 'Ciudad de Panamá', 'kontinent': 'Srednja Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 728 }, { 'id': 'BUS', 'n': 733 }] },
    { 'id': 'Georgetown', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 737 }, { 'id': 'BUS', 'n': 817 }] },
    { 'id': 'Kairo', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 539 }, { 'id': 'VL', 'n': 823 }, { 'id': 'BUS', 'n': 654 }] },
    { 'id': 'Kuala Lumpur', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 531 }, { 'id': 'BUS', 'n': 842 }] },
    { 'id': 'Lima', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 899 }, { 'id': 'BUS', 'n': 610 }] },
    { 'id': 'Mbabane', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 745 }, { 'id': 'BUS', 'n': 624 }] },
    { 'id': 'New Delhi', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 661 }, { 'id': 'BUS', 'n': 787 }] },
    { 'id': 'Pariz', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 223 }, { 'id': 'VL', 'n': 294 }, { 'id': 'BUS', 'n': 126 }] },
    { 'id': 'Peking', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 556 }, { 'id': 'BUS', 'n': 767 }] },
    { 'id': 'Prag', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 111 }, { 'id': 'VL', 'n': 106 }, { 'id': 'BUS', 'n': 127 }] },
    { 'id': 'Quito', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 852 }, { 'id': 'BUS', 'n': 679 }] },
    { 'id': 'Santiago', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 828 }, { 'id': 'BUS', 'n': 649 }] },
    { 'id': 'São Tomé', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 603 }, { 'id': 'BROD', 'n': 706 }] },
    { 'id': 'Sarajevo', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 180 }, { 'id': 'VL', 'n': 206 }, { 'id': 'BUS', 'n': 201 }] },
    { 'id': 'Tokio', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 758 }, { 'id': 'BUS', 'n': 554 }] },
    { 'id': 'Valletta', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 287 }, { 'id': 'BROD', 'n': 234 }] },
    { 'id': 'Zagreb', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 239 }, { 'id': 'VL', 'n': 201 }, { 'id': 'BUS', 'n': 272 }] },
    { 'id': 'Canberra', 'kontinent': 'Australija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 574 }, { 'id': 'BUS', 'n': 755 }] },
    { 'id': 'Oslo', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 206 }, { 'id': 'VL', 'n': 199 }, { 'id': 'BUS', 'n': 270 }] },
    { 'id': 'Nairobi', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 864 }, { 'id': 'BUS', 'n': 557 }] },
    { 'id': 'Addis Abeba', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 573 }, { 'id': 'BUS', 'n': 619 }] },
    { 'id': 'Manila', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 851 }, { 'id': 'BUS', 'n': 861 }] },
    { 'id': 'Makao', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 647 }, { 'id': 'BUS', 'n': 793 }] },
    { 'id': 'Niamey', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 788 }, { 'id': 'BUS', 'n': 676 }] },
    { 'id': 'Kampala', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 526 }, { 'id': 'BUS', 'n': 871 }] },
    { 'id': 'Jakarta', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 556 }, { 'id': 'BUS', 'n': 847 }] },
    { 'id': 'Kingston', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 679 }, { 'id': 'BUS', 'n': 801 }] },
    { 'id': 'Reykjavik', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 233 }, { 'id': 'BROD', 'n': 204 }] },
    { 'id': 'Asmara', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 685 }, { 'id': 'BUS', 'n': 536 }] },
    { 'id': 'Oranjestad', 'kontinent': 'Karibi', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 857 }, { 'id': 'BROD', 'n': 629 }] },
    { 'id': 'Pyongyang', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 802 }, { 'id': 'BUS', 'n': 824 }] },
    { 'id': 'Lomé', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 649 }, { 'id': 'BUS', 'n': 780 }] },
    { 'id': 'Lilongwe', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 830 }, { 'id': 'BUS', 'n': 644 }] },
    { 'id': 'Seoul', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 740 }, { 'id': 'BUS', 'n': 808 }] },
    { 'id': 'The Valley', 'kontinent': 'Karibi', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 768 }, { 'id': 'BROD', 'n': 705 }] },
    { 'id': 'Maputo', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 890 }, { 'id': 'BUS', 'n': 527 }] },
    { 'id': 'Wellington', 'kontinent': 'Australija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 579 }, { 'id': 'BUS', 'n': 804 }] },
    { 'id': 'Port Louis', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 738 }, { 'id': 'BROD', 'n': 866 }] },
    { 'id': 'Lisabon', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 262 }, { 'id': 'VL', 'n': 286 }, { 'id': 'BUS', 'n': 244 }] },
    { 'id': 'Gaborone', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 690 }, { 'id': 'BUS', 'n': 721 }] },
    { 'id': 'West Island', 'kontinent': 'Okeanija', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 741 }, { 'id': 'BROD', 'n': 757 }] },
    { 'id': 'Bissau', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 677 }, { 'id': 'BUS', 'n': 775 }] },
    { 'id': 'Bandar Seri Begawan', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 723 }, { 'id': 'BUS', 'n': 852 }] },
    { 'id': 'Rim', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 225 }, { 'id': 'VL', 'n': 250 }, { 'id': 'BUS', 'n': 204 }] },
    { 'id': 'Podgorica', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 140 }, { 'id': 'VL', 'n': 266 }, { 'id': 'BUS', 'n': 289 }] },
    { 'id': 'Varšava', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 131 }, { 'id': 'VL', 'n': 278 }, { 'id': 'BUS', 'n': 265 }] },
    { 'id': 'Papeete', 'kontinent': 'Okeanija', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 580 }, { 'id': 'BROD', 'n': 833 }] },
    { 'id': 'Yaren', 'kontinent': 'Okeanija', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 656 }, { 'id': 'BROD', 'n': 615 }] },
    { 'id': 'Singapur', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 589 }, { 'id': 'BUS', 'n': 821 }] },
    { 'id': 'Riga', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 265 }, { 'id': 'VL', 'n': 293 }, { 'id': 'BUS', 'n': 238 }] },
    { 'id': 'Praia', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 844 }, { 'id': 'BUS', 'n': 784 }] },
    { 'id': 'Ouagadougou', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 557 }, { 'id': 'BUS', 'n': 556 }] },
    { 'id': 'Antananarivo', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 679 }, { 'id': 'BUS', 'n': 782 }] },
    { 'id': 'Kabul', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 507 }, { 'id': 'BUS', 'n': 806 }] },
    { 'id': 'Saint-Denis', 'kontinent': 'Okeanija', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 516 }, { 'id': 'BROD', 'n': 753 }] },
    { 'id': 'Asunción', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 897 }, { 'id': 'BUS', 'n': 882 }] },
    { 'id': 'Sofia', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 277 }, { 'id': 'VL', 'n': 259 }, { 'id': 'BUS', 'n': 232 }] },
    { 'id': 'Bruxelles', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 286 }, { 'id': 'VL', 'n': 168 }, { 'id': 'BUS', 'n': 204 }] },
    { 'id': 'Luanda', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 586 }, { 'id': 'BUS', 'n': 753 }] },
    { 'id': 'Kopenhagen', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 136 }, { 'id': 'VL', 'n': 295 }, { 'id': 'BUS', 'n': 198 }] },
    { 'id': 'Dodoma', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 765 }, { 'id': 'BUS', 'n': 600 }] },
    { 'id': 'San José', 'kontinent': 'Srednja Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 745 }, { 'id': 'BUS', 'n': 604 }] },
    { 'id': 'Bishkek', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 835 }, { 'id': 'BUS', 'n': 552 }] },
    { 'id': 'Victoria', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 644 }, { 'id': 'BUS', 'n': 727 }] },
    { 'id': 'Brazzaville', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 695 }, { 'id': 'BUS', 'n': 665 }] },
    { 'id': 'Tehran', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 856 }, { 'id': 'BUS', 'n': 646 }] },
    { 'id': 'Gibraltar', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 191 }, { 'id': 'BROD', 'n': 244 }] },
    { 'id': 'Andorra la Vella', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 219 }, { 'id': 'BUS', 'n': 129 }] },
    { 'id': 'Pretoria', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 687 }, { 'id': 'BUS', 'n': 750 }] },
    { 'id': 'Helsinki', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 113 }, { 'id': 'BUS', 'n': 210 }] },
    { 'id': 'Maseru', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 666 }, { 'id': 'BUS', 'n': 865 }] },
    { 'id': 'Kigali', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 512 }, { 'id': 'BUS', 'n': 662 }] },
    { 'id': 'Nouakchott', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 890 }, { 'id': 'BUS', 'n': 707 }] },
    { 'id': 'Masqat', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 717 }, { 'id': 'BUS', 'n': 890 }] },
    { 'id': 'Honiara', 'kontinent': 'Okeanija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 866 }, { 'id': 'BUS', 'n': 709 }] },
    { 'id': 'Bukurešt', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 182 }, { 'id': 'VL', 'n': 176 }, { 'id': 'BUS', 'n': 130 }] },
    { 'id': 'Abu Dhabi', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 516 }, { 'id': 'BUS', 'n': 741 }] },
    { 'id': 'Ottawa', 'kontinent': 'Sjeverna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 831 }, { 'id': 'BUS', 'n': 733 }] },
    { 'id': 'Cardiff', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 114 }, { 'id': 'VL', 'n': 120 }, { 'id': 'BUS', 'n': 232 }] },
    { 'id': 'Città del Vaticano', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 165 }, { 'id': 'VL', 'n': 292 }, { 'id': 'BUS', 'n': 230 }] },
    { 'id': 'Paramaribo', 'kontinent': 'Južna Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 805 }, { 'id': 'BUS', 'n': 617 }] },
    { 'id': 'Basseterre', 'kontinent': 'Srednja Amerika', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 821 }, { 'id': 'BROD', 'n': 658 }] },
    { 'id': 'Skopje', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 262 }, { 'id': 'VL', 'n': 172 }, { 'id': 'BUS', 'n': 184 }] },
    { 'id': 'Thimphu', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 797 }, { 'id': 'BUS', 'n': 830 }] },
    { 'id': 'Ankara', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 251 }, { 'id': 'BUS', 'n': 105 }] },
    { 'id': 'Mamoudzou', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 674 }, { 'id': 'BUS', 'n': 866 }] },
    { 'id': 'Dušanbe', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 525 }, { 'id': 'BUS', 'n': 613 }] },
    { 'id': 'Ljubljana', 'kontinent': 'Europa', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 131 }, { 'id': 'VL', 'n': 105 }, { 'id': 'BUS', 'n': 211 }] },
    { 'id': 'Tegucigalpa', 'kontinent': 'Srednja Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 820 }, { 'id': 'BUS', 'n': 530 }] },
    { 'id': 'Yamoussoukro', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 595 }, { 'id': 'BUS', 'n': 759 }] },
    { 'id': 'Belmopan', 'kontinent': 'Srednja Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 637 }, { 'id': 'BUS', 'n': 712 }] },
    { 'id': 'Port-au-Prince', 'kontinent': 'Srednja Amerika', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 733 }, { 'id': 'BUS', 'n': 538 }] },
    { 'id': 'Erevan', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 588 }, { 'id': 'BUS', 'n': 886 }] },
    { 'id': 'Flying Fish Cove', 'kontinent': 'Okeanija', 'prijevoz': ['AV', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 791 }, { 'id': 'BROD', 'n': 799 }] },
    { 'id': 'Adis Abeba', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'BUS', 'VL'], 'cijena': [{ 'id': 'AV', 'n': 571 }, { 'id': 'VL', 'n': 552 }, { 'id': 'BUS', 'n': 675 }] },
    { 'id': 'Asmera', 'kontinent': 'Afrika', 'prijevoz': ['AV', 'VL', 'BUS'], 'cijena': [{ 'id': 'AV', 'n': 633 }, { 'id': 'VL', 'n': 767 }, { 'id': 'BUS', 'n': 502 }] },
    { 'id': 'Pjongjang', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS', 'VL'], 'cijena': [{ 'id': 'AV', 'n': 879 }, { 'id': 'VL', 'n': 581 }, { 'id': 'BUS', 'n': 565 }] },
    { 'id': 'Vis', 'kontinent': 'Europa', 'prijevoz': ['BROD'], 'cijena': [{ 'id': 'BROD', 'n': 197 }] },
    { 'id': 'Lisbon', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BUS', 'VLAK', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 229 }, { 'id': 'VL', 'n': 279 }, { 'id': 'BUS', 'n': 243 }, { 'id': 'BROD', 'n': 104 }] },
    { 'id': 'Warszawa', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BUS', 'VLAK'], 'cijena': [{ 'id': 'AV', 'n': 279 }, { 'id': 'VL', 'n': 249 }, { 'id': 'BUS', 'n': 195 }] },
    { 'id': 'Copenhagen', 'kontinent': 'Europa', 'prijevoz': ['AV', 'BUS', 'VLAK', 'BROD'], 'cijena': [{ 'id': 'AV', 'n': 145 }, { 'id': 'VL', 'n': 281 }, { 'id': 'BUS', 'n': 232 }, { 'id': 'BROD', 'n': 127 }] },
    { 'id': 'Ankaru', 'kontinent': 'Azija', 'prijevoz': ['AV', 'BUS', 'VLAK'], 'cijena': [{ 'id': 'AV', 'n': 722 }, { 'id': 'VL', 'n': 625 }, { 'id': 'BUS', 'n': 853 }] },
    { "id": "Paket1", "kontinent": "all", "prijevoz": ["BUS"], "cijena": [{ "id": "BUS", "n": 300 }] },
    { "id": "Paket2", "kontinent": "all", "prijevoz": ["AV"], "cijena": [{ "id": "AV", "n": 1500 }] },
    { "id": "Paket3", "kontinent": "all", "prijevoz": ["BROD"], "cijena": [{ "id": "BROD", "n": 1000 }] },
    { "id": "Paket4", "kontinent": "all", "prijevoz": ["VL"], "cijena": [{ "id": "VL", "n": 700 }] }
]
// brod-brod/ av-avion/ bus-bus/ vl-vlak

let currentUserIndex = null;
let userIndex;
// ^^^^ ovo postoji ako zelis izbrisat racun sta cu kasnije napravit
let i = 0;
let currentUser = null;
let loggedIn = false;
let brojKorisnika = 0;

// ako brkorisnika ne postoji u local storageu, onda je broj korisnika 0.
// ako postoji, onda je broj korisnika jednak već zabilježenom broju korisnika u local storageu.
function addVariables() {
    if (localStorage.getItem("brKorisnika") === null) {
        brojKorisnika = 0;
    } else {
        brojKorisnika = Number(localStorage.getItem("brKorisnika"));
    }
    if (localStorage.getItem("currentUser") === null) {
        currentUser = null;
        localStorage.setItem("loggedIn", "false");
    } else if (localStorage.getItem("currentUser") != null) {
        currentUser = localStorage.getItem("currentUser");
        loggedIn = true;
        localStorage.setItem("loggedIn", "true");
    }
}

function updateLoginState() {
    if (
        localStorage.getItem("currentUser") == "null" ||
        localStorage.getItem("currentUser") == null
    ) {
        currentUser = null;
        loggedIn = false;
        localStorage.setItem("loggedIn", "false");
    } else if (localStorage.getItem("currentUser") != "null") {
        currentUser = localStorage.getItem("currentUser");
        loggedIn = true;
        localStorage.setItem("loggedIn", "true");
    }
}
addVariables();
// ZA REGISTER.HTML:
function register() {
    let username = document.getElementById("ime").value;
    let mail = document.getElementById("mail").value;
    let sifra = document.getElementById("sifra").value;
    let i = brojKorisnika;
    // provjerava je li korisnik već prijavljen:
    if (loggedIn === "true") {
        alert("Već ste prijavljeni!");
        return;
    }
    // provjerava je li račun već registriran:
    else if (
        localStorage.getItem(`username${i}`) == username &&
        localStorage.getItem(`mail${i}`) == mail
    ) {
        alert("Ovaj račun je već registriran!");
        return;
    }
    // ako je sve ostalo ok, onda te registrira.
    else {
        event.preventDefault();
        localStorage.setItem(`username${i}`, username);
        localStorage.setItem(`mail${i}`, mail);
        localStorage.setItem(`pass${i}`, sifra);
        localStorage.setItem(`avatar${i}`, 0);
        brojKorisnika++;
        localStorage.setItem(`admin${i}`, false);
        localStorage.setItem("currentUser", username);
        localStorage.setItem("currentUserIndex", i);
        localStorage.setItem("loggedIn", "true");
        window.location.href = "index.html";
        localStorage.setItem("brKorisnika", brojKorisnika);
        alert("Registracija uspješna!");
        return;
    }
}
// ZA LOGIN.HTML:
function login() {
    let mmail = document.getElementById("mmail").value;
    let ssifra = document.getElementById("ssifra").value;
    let brojac = 0;
    for (i = 0; i < brojKorisnika + 1; i++) {
        if (loggedIn === true) {
            alert("Već ste prijavljeni!");
            return;
        } else if (mmail == "" || ssifra == "") {
            alert("Molimo ispunite sva polja!");
            return;
        } else if (
            mmail === localStorage.getItem(`mail${i}`) &&
            ssifra === localStorage.getItem(`pass${i}`)
        ) {
            event.preventDefault();
            localStorage.setItem("currentUserIndex", i);
            currentUser = localStorage.getItem(`username${i}`);
            localStorage.setItem("currentUser", currentUser);
            localStorage.setItem("loggedIn", "true");
            alert("Uspješno ste se prijavili!");
            window.location.href = "index.html";
            brojac++;
            return;
        } else if (mmail === "admin" && ssifra === "3zy2nExu!") {
            event.preventDefault();
            alert("AAAAAAAAAAAAAAAAA");
            localStorage.setItem("admin", "true");
            window.location.href = "/OSNOVNO/nez.html";
            return;
        }
    }
    if (brojac == 0) {
        alert("Korisnički podatci su neispravni!");
    }
    localStorage.setItem("brKorisnika", brojKorisnika);
}
function logout() {
    if (loggedIn === false) {
        alert("Niste prijavljeni!");
    } else {
        localStorage.setItem("currentUser", null);
        currentUser = null;
        localStorage.removeItem("loggedIn");
        localStorage.setItem("loggedIn", "false");
        loggedIn = false;
        localStorage.setItem("cart" + localStorage.getItem("currentUserIndex"), "[]")
        localStorage.setItem("currentUserIndex", null);
        localStorage.setItem("avatar", null);

        alert("Uspješno ste se odjavili!");
        window.location.href = "index.html";


    }

    if (localStorage.getItem("currentUser") === null) {
        localStorage.setItem("loggedIn", "false");
    }
}
function clearLocalStorage() {
    localStorage.clear();
    alert("Local storage je izbrisan.");
    window.location.reload();
}
document.addEventListener("DOMContentLoaded", function () {
    updateLoginState();
    if (localStorage.getItem("loggedIn") == "true") {
        document.getElementById(
            "aaa"
        ).innerHTML = `<a onclick="logout()">Odjavi se</a>`;
    } else {
        document.getElementById(
            "aaa"
        ).innerHTML = `<a href="register.html">Registriraj se</a>`;
    }

    if (localStorage.getItem("loggedIn") == "true") {
        document.getElementById("welcome").innerHTML = currentUser + "!";
    } else {
        document.getElementById("welcome").innerHTML = `na Wander!`;
    }
});

function changeUsername() {
    newuser = document.getElementById("newUsername").value;
    userIndex = localStorage.getItem("currentUserIndex");
    if (newuser != "" || newuser != null) {
        localStorage.setItem("username" + userIndex, newuser);
        localStorage.setItem("currentUser", newuser);
        alert("Vaše korisničko ime je uspješno promjenjeno!");
        window.location.reload();
    } else {
        alert("Molimo upišite novo korisničko ime!");
        return;
    }
}

function changeMail() {
    oldmail = document.getElementById("oldEmail").value;
    newmail = document.getElementById("newEmail").value;
    userIndex = localStorage.getItem("currentUserIndex");
    if (
        oldmail == localStorage.getItem("mail" + userIndex) &&
        newmail != "null" &&
        newmail != null
    ) {
        localStorage.setItem("mail" + userIndex, newmail);
        alert("E-mail adresa uspješno promjenjena!");
        window.location.reload();
    } else if (oldmail != localStorage.getItem("mail" + userIndex)) {
        alert("Netočna stara mail adresa!");
        return;
    } else {
        alert("Molimo Vas da ispunite sva polja!");
        return;
    }
}

function changePass() {
    oldpass = document.getElementById("oldPass").value;
    newpass = document.getElementById("newPass").value;
    userIndex = localStorage.getItem("currentUserIndex");
    if (
        oldpass == localStorage.getItem("pass" + userIndex) &&
        newpass != "null" &&
        newpass != null
    ) {
        localStorage.setItem("pass" + userIndex, newpass);
        alert("Lozinka za Vaš račun je uspješno promjenjena!");
        window.location.reload();
    } else if (oldpass != localStorage.getItem("pass" + userIndex)) {
        alert("Netočna stara lozinka!");
        return;
    } else {
        alert("Molimo Vas da ispunite sva polja!");
        return;
    }
}

function deleteAccount() {
    a = prompt(
        "Jeste li sigurni da želite izbrisati ovaj račun? Ako da, ponovno upišite Vašu lozinku."
    );
    userIndex = localStorage.getItem("currentUserIndex");
    if (a == localStorage.getItem("pass" + userIndex)) {
        localStorage.removeItem("username" + userIndex);
        localStorage.removeItem("mail" + userIndex);
        localStorage.removeItem("pass" + userIndex);
        localStorage.removeItem("avatar" + userIndex);
        localStorage.setItem("currentUser", null);
        localStorage.setItem("currentUserIndex", null);
        localStorage.setItem("loggedIn", "false");
        alert("Račun uspješno izbrisan.");
        window.location.href = "/OSNOVNO/index.html";
    } else {
        alert("Netočna lozinka!");
        return;
    }
}

avatar = [
    {
        id: 0,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=ShortHairShortCurly&accessoriesType=Blank&hairColor=Brown&facialHairType=Blank&clotheType=BlazerShirt&eyeType=Default&eyebrowType=Default&mouthType=Default&skinColor=Light",
        alt: "muško",
        change: function () {
            localStorage.setItem(
                `avatar${localStorage.getItem("currentUserIndex")}`,
                0
            );
            alert("Avatar uspješno promjenjen!");
            window.location.reload();
        },
    },
    {
        id: 1,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=LongHairStraight&accessoriesType=Blank&hairColor=Brown&facialHairType=Blank&clotheType=ShirtVNeck&clotheColor=Gray01&eyeType=Default&eyebrowType=Default&mouthType=Default&skinColor=Light",
        alt: "žena",
        change: function () {
            localStorage.setItem(
                `avatar${localStorage.getItem("currentUserIndex")}`,
                1
            );
            alert("Avatar uspješno promjenjen!");
            window.location.reload();
        },
    },
    {
        id: 2,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=ShortHairShortCurly&accessoriesType=Blank&hairColor=Black&facialHairType=Blank&clotheType=BlazerSweater&eyeType=Default&eyebrowType=Default&mouthType=Default&skinColor=Black",
        alt: "crnac",
        change: function () {
            localStorage.setItem(
                `avatar${localStorage.getItem("currentUserIndex")}`,
                2
            );
            alert("Avatar uspješno promjenjen!");
            window.location.reload();
        },
    },
    {
        id: 3,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=LongHairCurly&accessoriesType=Blank&hairColor=Black&facialHairType=Blank&clotheType=ShirtVNeck&clotheColor=Black&eyeType=Default&eyebrowType=Default&mouthType=Default&skinColor=Black",
        alt: "crnkinja",
        change: function () {
            localStorage.setItem(
                `avatar${localStorage.getItem("currentUserIndex")}`,
                3
            );
            alert("Avatar uspješno promjenjen!");
            window.location.reload();
        },
    },
    {
        id: 4,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=ShortHairShortWaved&accessoriesType=Blank&hairColor=BrownDark&facialHairType=Blank&clotheType=BlazerShirt&eyeType=Side&eyebrowType=Default&mouthType=Default&skinColor=Tanned",
        alt: "azijat",
        change: function () {
            localStorage.setItem(
                `avatar${localStorage.getItem("currentUserIndex")}`,
                4
            );
            alert("Avatar uspješno promjenjen!");
            window.location.reload();
        },
    },
    {
        id: 5,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=LongHairNotTooLong&accessoriesType=Blank&hairColor=Black&facialHairType=Blank&clotheType=BlazerShirt&eyeType=Side&eyebrowType=Default&mouthType=Default&skinColor=Tanned",
        alt: "azijatkinja",
        change: function () {
            localStorage.setItem(
                `avatar${localStorage.getItem("currentUserIndex")}`,
                5
            );
            alert("Avatar uspješno promjenjen!");
            window.location.reload();
        },
    },
    {
        id: 6,
        img: "https://as2.ftcdn.net/v2/jpg/03/31/69/91/1000_F_331699188_lRpvqxO5QRtwOM05gR50ImaaJgBx68vi.jpg",
        alt: "niko",
        change: function () {
            localStorage.setItem(
                `avatar${localStorage.getItem("currentUserIndex")}`,
                6
            );
            alert("Avatar uspješno promjenjen!");
            window.location.reload();
        },
    },
];

function changeavatar() {
    let noviavatar = prompt(
        "Unesi link slike ili GIF-a za svoj avatar (slika na googleu -> desni klik -> Copy image address)"
    );
    localStorage.setItem(
        `avatar${localStorage.getItem("currentUserIndex")}`,
        noviavatar
    );
    alert("Link za promjenu avatara je uspješno poslan!");
    window.location.reload();
}

let prikazani_gradovi = "all";
document.getElementById("europa").addEventListener("change", filtrirajGradove);
document.getElementById("azija").addEventListener("change", filtrirajGradove);
document
    .getElementById("samerika")
    .addEventListener("change", filtrirajGradove);
document
    .getElementById("jamerika")
    .addEventListener("change", filtrirajGradove);
document.getElementById("autobus").addEventListener("change", filtrirajGradove);
document.getElementById("avion").addEventListener("change", filtrirajGradove);
document.getElementById("vlak").addEventListener("change", filtrirajGradove);
document.getElementById("bbrod").addEventListener("change", filtrirajGradove);

function filtrirajGradove() {
    let kontinenti = {};
    kontinenti["Europa"] = document.getElementById("europa").checked;
    kontinenti["Azija"] = document.getElementById("azija").checked;
    kontinenti["Sjeverna Amerika"] = document.getElementById("samerika").checked;
    kontinenti["Južna Amerika"] = document.getElementById("jamerika").checked;
    kontinent["all"] = true

    let prijevoz = {};
    prijevoz["BUS"] = document.getElementById("autobus").checked;
    prijevoz["AV"] = document.getElementById("avion").checked;
    prijevoz["VL"] = document.getElementById("vlak").checked;
    prijevoz["BROD"] = document.getElementById("bbrod").checked;

    for (let i = 0; i < gradovi.length; i++) {
        const grad = gradovi[i];
        const gradHTML = document.getElementById(grad.id);

        if (gradHTML) {
            let odgovarajuciKontinent = false;
            let odgovarajuciPrijevoz = false;

            if (kontinenti[grad.kontinent]) {
                odgovarajuciKontinent = true;
            }

            for (let j = 0; j < grad.prijevoz.length; j++) {
                const p = grad.prijevoz[j];
                if (prijevoz[p]) {
                    odgovarajuciPrijevoz = true;
                    break;
                }
            }

            if (odgovarajuciKontinent == true && odgovarajuciPrijevoz == true) {
                gradHTML.style.display = "block";
            } else {
                gradHTML.style.display = "none";
            }
        }
    }
}

window.onload = function () {
    setTimeout(() => {
        filtrirajGradove();
    }, 50);
};

function changeCreditentals(c) {
    if (
        confirm(
            "YOU ARE ABOUT TO BE REDIRECTED FROM THIS SITE, BUT STILL WILL HAVE ACCESS TO nez.html! DO YOU WISH TO PROCEED?"
        ) == true
    ) {
        localStorage.setItem("currentUser", localStorage.getItem("username" + c));
        localStorage.setItem("currentUserIndex", c);
        alert("Redirecting...");
        window.location.href = "racun.html";
    }
}
function makeAdmin(c) {
    if (
        localStorage.getItem("admin" + c) == false ||
        localStorage.getItem("admin" + c) == "false"
    ) {
        localStorage.setItem("admin" + c, true);
        alert(
            `Administrator privileges have been granted to ${localStorage.getItem(
                "username" + c
            )}.`
        );
        window.location.reload();
    } else if (
        localStorage.getItem("admin" + c) == true ||
        localStorage.getItem("admin" + c) == "true"
    ) {
        localStorage.setItem("admin" + c, false);
        alert(
            `Administrator privileges have been revoked from ${localStorage.getItem(
                "username" + c
            )}.`
        );
        window.location.reload();
    }
}
function erase(c) {
    if (
        confirm(
            "You are about to permenantly remove an account and all it's data. Rethink your choices if needed."
        ) == true
    ) {
        userIndex = c;
        localStorage.removeItem("username" + userIndex);
        localStorage.removeItem("mail" + userIndex);
        localStorage.removeItem("pass" + userIndex);
        localStorage.removeItem("avatar" + userIndex);
        localStorage.setItem("currentUser", null);
        localStorage.setItem("currentUserIndex", null);
        localStorage.setItem("loggedIn", "false");
        alert("Account successfully removed.");
        window.location.reload();
    }
}

function dajOcjenu() {
    let currentCity = window.location.href.split("/").pop().replace(".html", "");
    if (document.getElementById("5").checked) {
        localStorage.setItem(
            currentCity + localStorage.getItem("currentUserIndex"),
            5
        );
    } else if (document.getElementById("4").checked) {
        localStorage.setItem(
            currentCity + localStorage.getItem("currentUserIndex"),
            4
        );
    } else if (document.getElementById("3").checked) {
        localStorage.setItem(
            currentCity + localStorage.getItem("currentUserIndex"),
            3
        );
    } else if (document.getElementById("2").checked) {
        localStorage.setItem(
            currentCity + localStorage.getItem("currentUserIndex"),
            2
        );
    } else if (document.getElementById("1").checked) {
        localStorage.setItem(
            currentCity + localStorage.getItem("currentUserIndex"),
            1
        );
    }

    alert(
        `Uspješno ste dali ocjenu!`
    );
}


function search() {
    let results;
    results = [];

    let query = document.getElementById("searchbar").value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    localStorage.setItem("query", query)

    for (let i = 0; i < gradovi.length; i++) {
        let gradId = gradovi[i].id.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

        if (gradId.startsWith(query)) {
            results.push(gradovi[i].id);
        }
    }
    localStorage.setItem("results", JSON.stringify(results));
    window.location.href = "/OSNOVNO/search.html";
}

function getSearchResults() {
    let searchDiv = document.getElementById("searchResults");
    let results;
    results = JSON.parse(localStorage.getItem("results"));

    if (results.length === 0) {
        searchDiv.innerHTML = `
        <div role="alert" class="alert alert-error justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 shrink-0 stroke-current" fill="none" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>Greška! Rezultat nije pronađen!</span>
        </div>`;
    } else {
        for (let i = 0; i < results.length; i++) {
            searchDiv.innerHTML += `
    <div class="card w-96 bg-gray-100 card-xs shadow-lg">
        <div class="card-body">
            <h2 class="card-title">${results[i]}</h2>
            <div class="justify-end card-actions">
            <a href="/GRADOVI/${results[i]}.html"><button class="btn btn-primary">Pregledaj!</button></a>
            </div>
        </div>
    </div>
    `;
        }
    }
}


// trust
function dodaj_u_košaricu() {
    let selectedTransport = "";

    if (document.getElementById("avion").checked) {
        selectedTransport = "AV";
    } else if (document.getElementById("vlak").checked) {
        selectedTransport = "VL";
    } else if (document.getElementById("autobus").checked) {
        selectedTransport = "BUS";
    } else if (document.getElementById("brod").checked) {
        selectedTransport = "BROD";
    }

    if (selectedTransport == "") {
        alert("Molimo odaberite način prijevoza!")
        return;
    }
    let currentCityId = window.location.href
        .split("/")
        .pop()
        .replace(".html", "");
    let failCounter = 0
    let transportFound = false

    for (let i = 0; i < gradovi.length; i++) {
        if (currentCityId == gradovi[i].id) {
            for (let j = 0; j < gradovi[i].cijena.length; j++) {
                if (selectedTransport == gradovi[i].cijena[j].id) {
                    transportFound = true
                    let cijenaGrada = gradovi[i].cijena[j].n
                    localStorage.setItem(`${gradovi[i].id}Cijena`, cijenaGrada)
                    break;
                }
            }
        }
        if (transportFound == false) {
            failCounter++
        }
    }
    if (failCounter >= gradovi.length) {
        alert("Ne možete koristiti taj način prijevoza za ovaj grad!")
        return;
    }
    let currentUserIndex = localStorage.getItem("currentUserIndex")
    let cart = JSON.parse(localStorage.getItem(`cart${currentUserIndex}`))

    for (let i = 0; i < cart.length; i++) {
        if (cart[i].id === currentCityId) {
            alert("Već ste dodali ovaj grad u košaricu!");
            return;
        }
    }

    let city = {
        id: currentCityId,
        prijevoz: selectedTransport,
    }

    cart.push(city)

    localStorage.setItem(`cart${currentUserIndex}`, JSON.stringify(cart));

    alert("Uspješno dodano u košaricu!");
    window.location.reload();
    localStorage.setItem("total" + localStorage.getItem("currentUserIndex"), total);
}
// trust
function dodajUkosaricu() {
    let currentCityId = window.location.href
        .split("/")
        .pop()
        .replace(".html", "");

    let transportFound = false
    let cityPrice = null
    let foundCity = null

    for (let i = 0; i < gradovi.length; i++) {
        if (currentCityId == gradovi[i].id) {
            foundCity = gradovi[i]
            if (foundCity.cijena && foundCity.cijena.length > 0) {
                cityPrice = foundCity.cijena[0].n
                localStorage.setItem(`${foundCity.id}Cijena`, cityPrice)
                transportFound = true
            }
            break;
        }
    }

    let currentUserIndex = localStorage.getItem("currentUserIndex");
    let cart = JSON.parse(localStorage.getItem(`cart${currentUserIndex}`))

    for (let i = 0; i < cart.length; i++) {
        if (cart[i].id === currentCityId) {
            alert("Već ste dodali ovaj grad u košaricu!")
            return;
        }
    }

    if (!foundCity) {
        alert("Grad nije pronađen!")
        return;
    }

    let city = {
        id: currentCityId,
        prijevoz: foundCity.prijevoz[0],
        cijena: cityPrice
    }

    cart.push(city)
    localStorage.setItem(`cart${currentUserIndex}`, JSON.stringify(cart))

    alert("Uspješno dodano u košaricu!")
    window.location.reload()
}




// trust
function ukloniIzKosarice() {
    let currentUserIndex = localStorage.getItem("currentUserIndex")
    let cart = JSON.parse(localStorage.getItem(`cart${currentUserIndex}`))

    for (let i = 0; i < cart.length; i++) {
        if (
            cart[i].id === window.location.href.split("/").pop().replace(".html", "")
        ) {
            cart.splice(i, 1)
            alert("Uspješno ste uklonili proizvod iz košarice!")
            localStorage.setItem(`cart${currentUserIndex}`, JSON.stringify(cart))
            window.location.reload()
            return;
        }
    }

    alert("Ovaj grad nije u košarici!")
}
// TRUST
function makniIzKosarice(grad) {
    for (let i = 0; i < cart.length; i++) {
        let currentUserIndex = localStorage.getItem("currentUserIndex")
        let cart = JSON.parse(localStorage.getItem(`cart${currentUserIndex}`))
        if (cart[i].id === grad) {
            cart.splice(i, 1)
            alert("Uspješno ste uklonili proizvod iz košarice!")
            localStorage.setItem(`cart${currentUserIndex}`, JSON.stringify(cart))
            window.location.reload()
            return;
        }
    }
}
function prikaziKosaricu() {
    let cart = JSON.parse(localStorage.getItem("cart" + localStorage.getItem("currentUserIndex")))
    const cartItemsContainer = document.getElementById("cart-items")
    cartItemsContainer.innerHTML = ""

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="alert alert-error justify-center">
            <span class="text-center w-full">Košarica je prazna!</span>
            </div>`
        return;
    }

    let total = 0

    for (let i = 0; i < cart.length; i++) {
        const item = cart[i]

        const cartItemElement = document.createElement("div");
        cartItemElement.classList.add(
            "flex",
            "justify-between",
            "items-center",
            "border-b",
            "pb-4"
        )

        const cityName = decodeURIComponent(item.id);

        cartItemElement.innerHTML = `
          <span class="font-semibold">${cityName}</span>
          <span>${item.prijevoz}</span>
          <span>${"$" + localStorage.getItem(cityName + "Cijena") + ",00"}</span>
          <button onclick="makniIzKosarice('${item.id}')" class="btn btn-error">Ukloni</button>
        `;

        cartItemsContainer.appendChild(cartItemElement);
        total += Number(localStorage.getItem(cityName + "Cijena"))

        localStorage.setItem("total" + localStorage.getItem("currentUserIndex"), total);
        document.getElementById("ukupno").innerHTML = `Ukupno: $${total},00`
    }
}

function getItemCount() {
    cart = JSON.parse(
        localStorage.getItem("cart" + localStorage.getItem("currentUserIndex"))
    );
    itemCount = document.getElementById("item-count");
    itemCount.innerHTML = cart.length;
}
function getPriceCount() {
    let priceCount = document.getElementById("price-count");
    totalPrice = localStorage.getItem(
        `total${localStorage.getItem("currentUserIndex")}`
    );

    if (totalPrice != null) {
        priceCount.innerHTML = "Ukupno: " + totalPrice + "$";
    } else if (totalPrice == "" || totalPrice == null || totalPrice == "0" || totalPrice == 0 || totalPrice == []) {
        priceCount.innerHTML = "Ukupno: 0,00$";
    }
    else {
        priceCount.innerHTML = "Ukupno: 0,00$";
    }
}

setInterval(() => {
    if (cart.length == 0) {
        localStorage.setItem("total" + localStorage.getItem("currentUserIndex"), 0);
    }
}, 1000);
setInterval(() => {
    getPriceCount()
}, 1000);


function neradi() {
    alert("Košarica je prazna!");
}
