const gradovi = [
    { id: "Bangkok", kontinent: "Azija", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Beograd", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Berlin", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Brasília", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Buenos Aires", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Ciudad de Panamá", kontinent: "Srednja Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Georgetown", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Kairo", kontinent: "Afrika", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Kuala Lumpur", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Lima", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Mbabane", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "New Delhi", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Pariz", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Peking", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Prag", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Quito", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Santiago", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "São Tomé", kontinent: "Afrika", prijevoz: ["AV", "BROD"] },
    { id: "Sarajevo", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Tokio", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Valletta", kontinent: "Europa", prijevoz: ["AV", "BROD"] },
    { id: "Zagreb", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Canberra", kontinent: "Australija", prijevoz: ["AV", "BUS"] },
    { id: "Oslo", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Nairobi", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Addis Abeba", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Manila", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Makao", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Niamey", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Kampala", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Jakarta", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Kingston", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Reykjavik", kontinent: "Europa", prijevoz: ["AV", "BROD", "AV"] },
    { id: "Asmara", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Oranjestad", kontinent: "Karibi", prijevoz: ["AV", "BROD"] },
    { id: "Pyongyang", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Lomé", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Lilongwe", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Seoul", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "The Valley", kontinent: "Karibi", prijevoz: ["AV", "BROD"] },
    { id: "Maputo", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Wellington", kontinent: "Australija", prijevoz: ["AV", "BUS"] },
    { id: "Port Louis", kontinent: "Afrika", prijevoz: ["AV", "BROD"] },
    { id: "Lisabon", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Gaborone", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "West Island", kontinent: "Okeanija", prijevoz: ["AV", "BROD"] },
    { id: "Bissau", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Bandar Seri Begawan", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Rim", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Podgorica", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Varšava", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Papeete", kontinent: "Okeanija", prijevoz: ["AV", "BROD"] },
    { id: "Yaren", kontinent: "Okeanija", prijevoz: ["AV", "BROD"] },
    { id: "Singapur", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Riga", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Praia", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Ouagadougou", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Antananarivo", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Kabul", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Saint-Denis", kontinent: "Okeanija", prijevoz: ["AV", "BROD"] },
    { id: "Asunción", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Sofia", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Bruxelles", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Luanda", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Kopenhagen", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Dodoma", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "San José", kontinent: "Srednja Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Bishkek", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Victoria", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Brazzaville", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Tehran", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Gibraltar", kontinent: "Europa", prijevoz: ["AV", "BROD", "AV"] },
    { id: "Andorra la Vella", kontinent: "Europa", prijevoz: ["AV", "BUS"] },
    { id: "Pretoria", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Helsinki", kontinent: "Europa", prijevoz: ["AV", "BUS"] },
    { id: "Maseru", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Kigali", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Nouakchott", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Masqat", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Honiara", kontinent: "Okeanija", prijevoz: ["AV", "BUS"] },
    { id: "Bukurešt", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Abu Dhabi", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Ottawa", kontinent: "Sjeverna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Cardiff", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Città del Vaticano", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Paramaribo", kontinent: "Južna Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Basseterre", kontinent: "Srednja Amerika", prijevoz: ["AV", "BROD"] },
    { id: "Skopje", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Thimphu", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Ankara", kontinent: "Europa", prijevoz: ["AV", "BUS"] },
    { id: "Mamoudzou", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Dušanbe", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Ljubljana", kontinent: "Europa", prijevoz: ["AV", "VL", "BUS"] },
    { id: "Tegucigalpa", kontinent: "Srednja Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Yamoussoukro", kontinent: "Afrika", prijevoz: ["AV", "BUS"] },
    { id: "Belmopan", kontinent: "Srednja Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Port-au-Prince", kontinent: "Srednja Amerika", prijevoz: ["AV", "BUS"] },
    { id: "Erevan", kontinent: "Azija", prijevoz: ["AV", "BUS"] },
    { id: "Flying Fish Cove", kontinent: "Okeanija", prijevoz: ["AV", "BROD"] }
];
// brod-brod/ av-avion/ bus-bus/ vl-vlak







let currentUserIndex = null
let userIndex;
// ^^^^ ovo postoji ako zelis izbrisat racun sta cu kasnije napravit
let i = 0
let currentUser = null
let loggedIn = false
let brojKorisnika = 0






// ako brkorisnika ne postoji u local storageu, onda je broj korisnika 0.
// ako postoji, onda je broj korisnika jednak već zabilježenom broju korisnika u local storageu.
function addVariables() {
    if (localStorage.getItem("brKorisnika") === null) {
        brojKorisnika = 0
    }
    else {
        brojKorisnika = Number(localStorage.getItem("brKorisnika"))
    }
    if (localStorage.getItem("currentUser") === null) {
        currentUser = null
        localStorage.setItem("loggedIn", "false")
    }
    else if (localStorage.getItem("currentUser") != null) {
        currentUser = localStorage.getItem("currentUser")
        loggedIn = true
        localStorage.setItem("loggedIn", "true")
    }
}



document.getElementById('BROJKORISNIKA').textContent = brojKorisnika; // probala sam povezat da tamo pise br korisnika bez uspjeha




function updateLoginState() {
    if (localStorage.getItem("currentUser") == "null" || localStorage.getItem("currentUser") == null) {
        currentUser = null
        loggedIn = false
        localStorage.setItem("loggedIn", "false")
    }
    else if (localStorage.getItem("currentUser") != "null") {
        currentUser = localStorage.getItem("currentUser")
        loggedIn = true
        localStorage.setItem("loggedIn", "true")
    }

}
addVariables()
// ZA REGISTER.HTML:
function register() {
    let username = document.getElementById("ime").value;
    let mail = document.getElementById("mail").value;
    let sifra = document.getElementById("sifra").value;
    let i = brojKorisnika
    // provjerava je li korisnik već prijavljen:
    if (loggedIn === "true") {
        alert("Već ste prijavljeni!")
        return
    }
    // provjerava je li račun već registriran:
    else if (localStorage.getItem(`username${i}`) == username && localStorage.getItem(`mail${i}`) == mail) {
        alert("Ovaj račun je već registriran!")
        return
    }
    // ako je sve ostalo ok, onda te registrira.
    else {
        event.preventDefault()
        localStorage.setItem(`username${i}`, username)
        localStorage.setItem(`mail${i}`, mail)
        localStorage.setItem(`pass${i}`, sifra)
        localStorage.setItem(`avatar${i}`, 0)
        brojKorisnika++
        localStorage.setItem("currentUser", username)
        localStorage.setItem("currentUserIndex", i)
        localStorage.setItem("loggedIn", "true")
        window.location.href = "index.html"
        localStorage.setItem("brKorisnika", brojKorisnika)
        alert("Registracija uspješna!")
        return
    }


}
// ZA LOGIN.HTML:
function login() {
    let mmail = document.getElementById("mmail").value;
    let ssifra = document.getElementById("ssifra").value;
    let brojac = 0
    for (i = 0; i < brojKorisnika + 1; i++) {

        if (loggedIn === true) {
            alert("Već ste prijavljeni!")
            return
        }
        else if (mmail == "" || ssifra == "") {
            alert("Molimo unesite sva polja!")
            return
        }
        else if (mmail === localStorage.getItem(`mail${i}`) && ssifra === localStorage.getItem(`pass${i}`)) {
            event.preventDefault()
            localStorage.setItem("currentUserIndex", i)
            currentUser = localStorage.getItem(`username${i}`)
            localStorage.setItem("currentUser", currentUser)
            localStorage.setItem("loggedIn", "true")
            alert("Uspješno ste se prijavili!")
            window.location.href = "index.html"
            brojac++
            return;
        }
        else if (mmail === "admin" && ssifra === "3zy2nExu!") {
            event.preventDefault()
            alert("AAAAAAAAAAAAAAAAA")
            localStorage.setItem("admin", "true")
            window.location.href = "/OSNOVNO/nez.html"
            return;
        }


    }
    if (brojac == 0) {
        alert("Korisnički podatci su neispravni!")
    }
    localStorage.setItem("brKorisnika", brojKorisnika)
}
function logout() {
    if (loggedIn === false) {
        alert("Niste prijavljeni!")
    }
    else {
        localStorage.setItem("currentUser", null)
        currentUser = null
        localStorage.removeItem("loggedIn")
        localStorage.setItem("loggedIn", "false")
        loggedIn = false
        alert("Uspješno ste se odjavili!")
        window.location.href = "index.html"
        window.location.reload()
        localStorage.setItem("currentUserIndex", null)
        localStorage.setItem("avatar", null)
    }


    if (localStorage.getItem("currentUser") === null) {
        localStorage.setItem("loggedIn", "false")
    }
}
function clearLocalStorage() {
    localStorage.clear()
    console.log("Local storage je izbrisan.")
}
document.addEventListener("DOMContentLoaded", function () {
    updateLoginState()
    if (localStorage.getItem("loggedIn") == "true") {
        console.log("aaa")
        document.getElementById("aaa").innerHTML = `<a onclick="logout()">Odjavi se</a>`
    }
    else {
        document.getElementById("aaa").innerHTML = `<a href="register.html">Registriraj se</a>`
    }

    if (localStorage.getItem("loggedIn") == "true") {
        document.getElementById("welcome").innerHTML = currentUser + "!"
    }
    else {
        document.getElementById("welcome").innerHTML = `na našu stranicu!`
    }
})


function changeUsername() {
    newuser = document.getElementById("newUsername").value
    userIndex = localStorage.getItem("currentUserIndex")
    if (newuser == "avatar6"){
        localStorage.setItem(`avatar${localStorage.getItem("currentUserIndex")}`,6)
        alert("YI FROM NINE SOLS")
        window.location.reload()
    }
    else if (newuser != "" || newuser != null) {

        localStorage.setItem("username" + userIndex, newuser)
        localStorage.setItem("currentUser", newuser)
        alert("Vaše korisničko ime je uspješno promjenjeno!")
        window.location.reload()
    }

    
    else {
        alert("Molimo upišite novo korisničko ime!")
        return;
    }
}

function changeMail() {
    oldmail = document.getElementById("oldEmail").value;
    newmail = document.getElementById("newEmail").value;
    userIndex = localStorage.getItem("currentUserIndex")
    if (oldmail == localStorage.getItem("mail" + userIndex) && newmail != "null" && newmail != null) {
        localStorage.setItem("mail" + userIndex, newmail)
        alert("E-mail adresa uspješno promjenjena!")
        window.location.reload()
    }
    else if (oldmail != localStorage.getItem("mail" + userIndex)) {
        alert("Netočna stara mail adresa!")
        return;
    }
    else {
        alert("Molimo Vas da ispunite sva polja!")
        return;
    }
}

function changePass() {
    oldpass = document.getElementById("oldPass").value;
    newpass = document.getElementById("newPass").value;
    userIndex = localStorage.getItem("currentUserIndex")
    if (oldpass == localStorage.getItem("pass" + userIndex) && newpass != "null" && newpass != null) {
        localStorage.setItem("pass" + userIndex, newpass)
        alert("Lozinka za Vaš račun je uspješno promjenjena!")
        window.location.reload()
    }
    else if (oldpass != localStorage.getItem("pass" + userIndex)) {
        alert("Netočna stara lozinka!")
        return;
    }
    else {
        alert("Molimo Vas da ispunite sva polja!")
        return;
    }
}


function deleteAccount() {
    a = prompt("Jeste li sigurni da želite izbrisati ovaj račun? Ako da, ponovno upišite Vašu lozinku.")
    userIndex = localStorage.getItem("currentUserIndex")
    if (a == localStorage.getItem("pass" + userIndex)) {
        localStorage.removeItem("username" + userIndex)
        localStorage.removeItem("mail" + userIndex)
        localStorage.removeItem("pass" + userIndex)
        localStorage.setItem("currentUser", null)
        localStorage.setItem("currentUserIndex", null)
        localStorage.setItem("loggedIn", "false")
        alert("Račun uspješno izbrisan.")
        window.location.href = "/OSNOVNO/index.html"
    }
    else {
        alert("Netočna lozinka!")
        return;
    }
}

avatar = [
    {
        id: 0,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=ShortHairShortCurly&accessoriesType=Blank&hairColor=Brown&facialHairType=Blank&clotheType=BlazerShirt&eyeType=Default&eyebrowType=Default&mouthType=Default&skinColor=Light",
        alt: "muško",
        change: function () {
            localStorage.setItem(`avatar${localStorage.getItem("currentUserIndex")}`, 0)
            alert("Avatar uspješno promjenjen!")
            window.location.reload()
        }
    },
    {
        id: 1,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=LongHairStraight&accessoriesType=Blank&hairColor=Brown&facialHairType=Blank&clotheType=ShirtVNeck&clotheColor=Gray01&eyeType=Default&eyebrowType=Default&mouthType=Default&skinColor=Light",
        alt: "žena",
        change: function () {
            localStorage.setItem(`avatar${localStorage.getItem("currentUserIndex")}`, 1)
            alert("Avatar uspješno promjenjen!")
            window.location.reload()
        }
    },
    {
        id: 2,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=ShortHairShortCurly&accessoriesType=Blank&hairColor=Black&facialHairType=Blank&clotheType=BlazerSweater&eyeType=Default&eyebrowType=Default&mouthType=Default&skinColor=Black",
        alt: "crnac",
        change: function () {
            localStorage.setItem(`avatar${localStorage.getItem("currentUserIndex")}`, 2)
            alert("Avatar uspješno promjenjen!")
            window.location.reload()
        }
    },
    {
        id: 3,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=LongHairCurly&accessoriesType=Blank&hairColor=Black&facialHairType=Blank&clotheType=ShirtVNeck&clotheColor=Black&eyeType=Default&eyebrowType=Default&mouthType=Default&skinColor=Black",
        alt: "crnkinja",
        change: function () {
            localStorage.setItem(`avatar${localStorage.getItem("currentUserIndex")}`, 3)
            alert("Avatar uspješno promjenjen!")
            window.location.reload()
        }
    },
    {
        id: 4,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=ShortHairShortWaved&accessoriesType=Blank&hairColor=BrownDark&facialHairType=Blank&clotheType=BlazerShirt&eyeType=Side&eyebrowType=Default&mouthType=Default&skinColor=Tanned",
        alt: "azijat",
        change: function () {
            localStorage.setItem(`avatar${localStorage.getItem("currentUserIndex")}`, 4)
            alert("Avatar uspješno promjenjen!")
            window.location.reload()
        }
    },
    {
        id: 5,
        img: "https://avataaars.io/?avatarStyle=Circle&topType=LongHairNotTooLong&accessoriesType=Blank&hairColor=Black&facialHairType=Blank&clotheType=BlazerShirt&eyeType=Side&eyebrowType=Default&mouthType=Default&skinColor=Tanned",
        alt: "azijatkinja",
        change: function () {
            localStorage.setItem(`avatar${localStorage.getItem("currentUserIndex")}`, 5)
            alert("Avatar uspješno promjenjen!")
            window.location.reload()
        }
    },
    {
        id: 6,
        img: "https://pbs.twimg.com/profile_images/1777849466630156288/5-hqm3qr_400x400.jpg",
        alt: "yi",
        change: function () {
            localStorage.setItem(`avatar${localStorage.getItem("currentUserIndex")}`, 6)
            alert("Avatar uspješno promjenjen!")
            window.location.reload()
        }
    }
]





//  za prominit boju crno bilo ili obrnuto  valjda
// let = "sunce"
// let = "mjesec"

// if (id =="sunce"){
//     document.getElementById("crno").style.color = "black"
 
// }
// else if(id =="mjesec"){
//     document.getElementById("bilo").style.color = "white"
   
// }