const gradovi = [
    { id: "Bangkok", kotinent: "Az"},
    { id: "Beograd", kotinent: "E"},
    { id: "Berlin", kotinent: "E"},
    { id: "Brasília", kotinent: "JA"},
    { id: "Buenos Aires", kotinent: "JA"},
    { id: "Ciudad de Panamá", kotinent: "SA"},
    { id: "Georgetown", kotinent: "JA"},
    { id: "Kairo", kotinent: "Af"},
    { id: "Kuala Lumpur", kotinent: "Az"},
    { id: "Lima", kotinent: "JA"},
    { id: "Mbabane", kotinent: "Af"},
    { id: "New Delhi", kotinent: "Az"},
    { id: "Pariz", kotinent: "E"},
    { id: "Peking", kotinent: "Az"},
    { id: "Prag", kotinent: "E"},
    { id: "Quito", kotinent: "JA"},
    { id: "Santiago", kotinent: "JA"},
    { id: "São Tomé", kotinent: "Af"},
    { id: "Sarajevo", kotinent: "E"},
    { id: "Tokio", kotinent: "Az"},
    { id: "Valletta", kotinent: "E"},
    { id: "Zagreb", kotinent: "E"},
];
// Canberra
// Oslo
// Nairobi
// Adis Abeba
// Manila